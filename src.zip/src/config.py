"""
Configuration — single source of truth for all pipeline parameters.
All constants in-code. No CLI arguments. Environment variables for secrets only.
"""

import os

# LLM Provider (auto-detect from env)
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "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")

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")

if OPENAI_API_KEY:
    LLM_PROVIDER = "openai"
elif ANTHROPIC_API_KEY:
    LLM_PROVIDER = "anthropic"
else:
    LLM_PROVIDER = "regex"

OPENAI_MODEL = "gpt-4o-mini"
OPENAI_TEMPERATURE = 0.0
ANTHROPIC_MODEL = "claude-sonnet-4-20250514"
ANTHROPIC_TEMPERATURE = 0.0

# Two-stage scorer models
EXTRACTION_MODEL = "gpt-4o-mini"   # Stage 1: cheap profile extraction
SCORING_MODEL = "gpt-4o"           # Stage 2: few-shot scoring with reasoning

# Embedding Models
EMBEDDING_MODEL = "all-MiniLM-L6-v2"
OPENAI_EMBEDDING_MODEL = "text-embedding-3-small"
OPENAI_EMBEDDING_DIM = 1536
CROSS_ENCODER_MODEL = "cross-encoder/ms-marco-MiniLM-L-6-v2"
EMBEDDING_DIM = 384
USE_OPENAI_EMBEDDINGS = bool(OPENAI_API_KEY)

# Retrieval
BM25_TOP_K = 50
DENSE_TOP_K = 50
RRF_K = 60
RERANK_TOP_N = 20

# Scoring
CRITICAL_SKILL_PENALTY = 0.85
CRITICAL_IMPORTANCE_THRESHOLD = 0.8  # importance >= 4 out of 5

# Paths
JD_DIR = "data/job_descriptions"
RESUME_DIR = "data/resumes"
GOLDEN_DATASET_PATH = "data/golden_dataset.jsonl"
FEEDBACK_DIR = "data/feedback"

# Determinism
RANDOM_SEED = 42
SCORE_PRECISION = 4
