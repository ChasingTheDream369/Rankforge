"""
Two-Stage LLM Scorer

Stage 1 (gpt-4o-mini): Extract JDProfile + ResumeProfile — structured JSON
  - JDProfile extracted fresh each run (JD may change)
  - ResumeProfile extracted once per resume, cached in IndexStore.skills_cache
  - Context engineering: only relevant structured fields passed to Stage 2

Stage 2 (gpt-4o, temp=0, few-shot): Score profiles → 4 dimensions + rationale
  - Few-shot grounded on FinPay golden dataset (priya_sharma GOOD, li_wei POOR)
  - Pydantic-style validation on JSON output
  - Agentic: if confidence == LOW → 1 bounded retry with verification prompt

Fallback: full deterministic pipeline if no API key.

Fusion formula:
  dim = 0.40*D1 + 0.35*D2 + 0.15*D3 + 0.10*D4
  alpha = min(0.25, 0.25*(N-1)/5)  — CE is minority signal (max 25%)
  raw = (1-alpha)*dim + alpha*sigmoid(ce_logit)
  final = raw * (1 - adversarial_penalty)
"""

import json
import math
import re
from typing import Dict, List, Optional

from src.config import (
    LLM_PROVIDER, OPENAI_API_KEY, OPENAI_TEMPERATURE,
    ANTHROPIC_API_KEY, ANTHROPIC_TEMPERATURE,
    EXTRACTION_MODEL, SCORING_MODEL,
    ANTHROPIC_MODEL,
)
from src.contracts import SkillEvidence

# ============================================================
# Dimension weights
# ============================================================

W_SKILLS = 0.40
W_SENIORITY = 0.35
W_DOMAIN = 0.15
W_CONSTRAINTS = 0.10
MAX_CE_WEIGHT = 0.25   # CE is minority signal
CE_RAMP_N = 5


# ============================================================
# LLM call helpers
# ============================================================

def _call_openai(prompt: str, model: str, max_tokens: int = 1000, system: str = "") -> Optional[str]:
    from openai import OpenAI
    client = OpenAI(api_key=OPENAI_API_KEY)
    msgs = []
    if system:
        msgs.append({"role": "system", "content": system})
    msgs.append({"role": "user", "content": prompt})
    resp = client.chat.completions.create(
        model=model, messages=msgs,
        max_tokens=max_tokens, temperature=OPENAI_TEMPERATURE,
    )
    return resp.choices[0].message.content


def _call_anthropic(prompt: str, max_tokens: int = 1000, system: str = "") -> Optional[str]:
    import anthropic
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
    resp = client.messages.create(
        model=ANTHROPIC_MODEL, max_tokens=max_tokens,
        temperature=ANTHROPIC_TEMPERATURE,
        system=system or "You are a precise structured extraction assistant.",
        messages=[{"role": "user", "content": prompt}],
    )
    return resp.content[0].text


def call_extraction_llm(prompt: str, max_tokens: int = 800, system: str = "") -> Optional[str]:
    """Stage 1 call — cheap model for profile extraction."""
    if LLM_PROVIDER == "openai":
        return _call_openai(prompt, EXTRACTION_MODEL, max_tokens, system)
    elif LLM_PROVIDER == "anthropic":
        return _call_anthropic(prompt, max_tokens, system)
    return None


def call_scoring_llm(prompt: str, max_tokens: int = 1000, system: str = "") -> Optional[str]:
    """Stage 2 call — capable model for few-shot scoring."""
    if LLM_PROVIDER == "openai":
        return _call_openai(prompt, SCORING_MODEL, max_tokens, system)
    elif LLM_PROVIDER == "anthropic":
        return _call_anthropic(prompt, max_tokens, system)
    return None


def is_resume(text: str) -> bool:
    """
    Fast gpt-4o-mini gate: returns False if the document is clearly NOT a resume.
    Called before any expensive extraction/scoring. Costs ~$0.0001 per call.
    Falls back to True (allow) if LLM is unavailable.
    """
    if LLM_PROVIDER not in ("openai", "anthropic"):
        return True  # deterministic mode — skip gate, let sanitizer penalty handle it

    snippet = text[:1200]  # first 1200 chars is enough to judge format
    prompt = (
        "Is the following document a professional resume or CV?\n"
        "Answer with exactly one word: YES or NO.\n\n"
        f"DOCUMENT:\n{snippet}"
    )
    try:
        raw = call_extraction_llm(prompt, max_tokens=5, system="You classify documents. Answer YES or NO only.")
        return raw is not None and raw.strip().upper().startswith("YES")
    except Exception:
        return True  # fail open — don't block on LLM error


def _parse_json(raw: Optional[str]) -> Optional[dict]:
    """Strip markdown fences and parse JSON. Returns None on failure."""
    if not raw:
        return None
    cleaned = raw.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r'^```(?:json)?\s*', '', cleaned)
        cleaned = re.sub(r'\s*```$', '', cleaned)
    try:
        return json.loads(cleaned)
    except Exception:
        return None


# ============================================================
# Stage 1: Profile Extraction (gpt-4o-mini)
# ============================================================

_JD_EXTRACTION_SYSTEM = (
    "You are a structured extraction assistant. Extract information from job descriptions "
    "into clean JSON. Be precise and terse. No markdown outside JSON."
)

_JD_EXTRACTION_PROMPT = """Extract a structured profile from this job description. Return JSON only.

JOB DESCRIPTION:
{jd_text}

Return this exact structure:
{{
  "required_skills": [{{"name": "skill", "importance": "core|nice"}}],
  "years_required": 0,
  "domain": "short domain label e.g. fintech/payments",
  "seniority": "junior|mid|senior|staff",
  "hard_constraints": ["plain english constraint"]
}}

Rules:
- List at most 10 skills. Mark 'core' only for must-haves.
- years_required: extract from text, 0 if not stated.
- hard_constraints: specific binary requirements (years, certs, specific tech)."""


_RESUME_EXTRACTION_SYSTEM = (
    "You are a structured extraction assistant. Extract information from resumes "
    "into clean JSON. Be precise. Quote exact phrases as evidence."
)

_RESUME_EXTRACTION_PROMPT = """Extract a structured profile from this resume. Return JSON only.

RESUME:
{resume_text}

Return this exact structure:
{{
  "skills": [{{"name": "skill", "level": "BUILT_WITH|USED|LISTED", "evidence": "short quote"}}],
  "total_years": 0,
  "domains": ["domain1", "domain2"],
  "seniority_signals": {{
    "leadership": "quote or null",
    "architecture": "quote or null",
    "scale": "quote or null",
    "ownership": "quote or null"
  }},
  "highlights": ["1-line highlight 1", "1-line highlight 2"]
}}

Rules:
- BUILT_WITH: action verb + skill + measurable outcome
- USED: skill in project/role context without clear ownership
- LISTED: skill-list only, no context
- Limit skills to 12 most relevant. Total_years from work history span."""


def extract_jd_profile(jd_text: str) -> Optional[dict]:
    """Stage 1a: Extract structured JD profile. Always fresh (JD changes each run)."""
    prompt = _JD_EXTRACTION_PROMPT.format(jd_text=jd_text[:2500])
    raw = call_extraction_llm(prompt, max_tokens=600, system=_JD_EXTRACTION_SYSTEM)
    result = _parse_json(raw)
    # Validate required keys
    if result and "required_skills" in result and "domain" in result:
        return result
    return None


def extract_resume_profile(resume_text: str) -> Optional[dict]:
    """Stage 1b: Extract structured resume profile. Cached in IndexStore per resume."""
    prompt = _RESUME_EXTRACTION_PROMPT.format(resume_text=resume_text[:3000])
    raw = call_extraction_llm(prompt, max_tokens=800, system=_RESUME_EXTRACTION_SYSTEM)
    result = _parse_json(raw)
    if result and "skills" in result and "total_years" in result:
        return result
    return None


# ============================================================
# Stage 2: Scoring (gpt-4o, few-shot, temp=0)
# ============================================================

_SCORING_SYSTEM = (
    "You are a senior technical recruiter scoring candidates against job requirements. "
    "Score based solely on evidence in the profiles. Temperature=0. No creativity. "
    "Return valid JSON matching the schema exactly."
)

# Few-shot examples grounded on FinPay golden dataset
_FEW_SHOT_EXAMPLES = """## FEW-SHOT EXAMPLES (learn from these)

### Example 1 — STRONG_MATCH (priya_sharma vs senior backend finpay)
JD_PROFILE: {"required_skills": [{"name": "Go/Python", "importance": "core"}, {"name": "PostgreSQL", "importance": "core"}, {"name": "AWS", "importance": "core"}, {"name": "Kafka", "importance": "core"}, {"name": "payment systems", "importance": "core"}, {"name": "microservices", "importance": "core"}], "years_required": 5, "domain": "fintech/payments", "seniority": "senior"}
RESUME_PROFILE: {"skills": [{"name": "Go/Python", "level": "BUILT_WITH", "evidence": "payment microservices handling 8000 TPS"}, {"name": "PostgreSQL", "level": "BUILT_WITH", "evidence": "50TB+ data, managed clusters"}, {"name": "Kafka", "level": "BUILT_WITH", "evidence": "event-driven microservices architecture"}, {"name": "AWS", "level": "BUILT_WITH", "evidence": "ECS migration, Lambda, SQS"}, {"name": "ETL/Airflow", "level": "BUILT_WITH", "evidence": "daily transaction reconciliation 15 currencies"}], "total_years": 7, "domains": ["fintech", "payments"], "seniority_signals": {"architecture": "migrated monolith to event-driven microservices", "leadership": "mentored 3 junior engineers, code review standards", "scale": "8000 TPS, 2M+ daily active users"}}
OUTPUT: {"d1_skills": 0.92, "d2_seniority": 0.88, "d3_domain": 1.0, "d4_constraints": 0.95, "confidence": "HIGH", "recommendation": "STRONG_MATCH", "strengths": ["Built payment microservices at 8000 TPS with Go/Python", "7 years fintech/payments domain with PCI-DSS leadership"], "gaps": [], "rationale": "Priya is an exceptional fit. She has built production payment microservices at massive scale (8000 TPS, 2M DAU), led PCI-DSS certification, and has 7 years of fintech experience exactly matching the role. All core technical requirements are met with strong evidence of ownership."}

### Example 2 — NO_MATCH (li_wei vs senior backend finpay)
JD_PROFILE: {"required_skills": [{"name": "Go/Python", "importance": "core"}, {"name": "PostgreSQL", "importance": "core"}, {"name": "AWS", "importance": "core"}, {"name": "Kafka", "importance": "core"}, {"name": "payment systems", "importance": "core"}, {"name": "microservices", "importance": "core"}], "years_required": 5, "domain": "fintech/payments", "seniority": "senior"}
RESUME_PROFILE: {"skills": [{"name": "Kubernetes/Docker", "level": "BUILT_WITH", "evidence": "platform engineering, cluster operations"}, {"name": "Go", "level": "LISTED", "evidence": "basic scripting only"}, {"name": "PostgreSQL", "level": "USED", "evidence": "operations/provisioning, not development"}, {"name": "Kafka", "level": "USED", "evidence": "cluster management, not stream processing"}, {"name": "Python", "level": "BUILT_WITH", "evidence": "CLI scripts and automation tooling"}], "total_years": 6, "domains": ["platform engineering", "devops"], "seniority_signals": {"architecture": "Kubernetes cluster design", "ownership": "infrastructure operations"}}
OUTPUT: {"d1_skills": 0.25, "d2_seniority": 0.45, "d3_domain": 0.3, "d4_constraints": 0.55, "confidence": "HIGH", "recommendation": "NO_MATCH", "strengths": ["Strong AWS/Kubernetes infra expertise", "Fintech-adjacent domain exposure"], "gaps": ["No backend API or product development experience", "No payment processing ownership", "Platform/DevOps role — not backend engineering", "Go only at basic scripting level"], "rationale": "Li Wei is a strong platform engineer but not a backend engineer. The role requires building payment APIs, transaction pipelines, and owning product services. His skills in Kubernetes and CI/CD are valuable for infra but do not map to the backend engineering responsibilities this role requires."}"""


_SCORING_PROMPT = """{few_shot}

---

## NOW SCORE THIS CANDIDATE

JD_PROFILE: {jd_profile_json}
RESUME_PROFILE: {resume_profile_json}

## Scoring Criteria
- D1 (Hard Skills, weight 0.40): For each core JD skill, assign BUILT_WITH=1.0, USED=0.7, LISTED=0.3, ABSENT=0.0. D1 = average.
- D2 (Seniority, weight 0.35): Leadership (team/mentoring), Architecture (system design), Scale (user/TPS metrics), Ownership (end-to-end). Combined signal 0.0-1.0.
- D3 (Domain Fit, weight 0.15): Same domain=1.0, adjacent/transferable=0.5-0.8, unrelated=0.0-0.3.
- D4 (Constraints, weight 0.10): Fraction of hard constraints met. Partial credit for close matches.
- confidence: HIGH if strong evidence for most scores, LOW if many gaps or uncertain signals.

Return JSON only (no markdown):
{{"d1_skills": 0.XX, "d2_seniority": 0.XX, "d3_domain": 0.XX, "d4_constraints": 0.XX, "confidence": "HIGH|MEDIUM|LOW", "recommendation": "STRONG_MATCH|GOOD_MATCH|PARTIAL_MATCH|WEAK_MATCH|NO_MATCH", "strengths": ["...", "..."], "gaps": ["...", "..."], "rationale": "one paragraph summary"}}"""


_VERIFY_PROMPT = """You initially scored a candidate with LOW confidence. Review your assessment and either confirm or revise.

JD_PROFILE: {jd_profile_json}
RESUME_PROFILE: {resume_profile_json}

INITIAL SCORES: D1={d1:.2f}, D2={d2:.2f}, D3={d3:.2f}, D4={d4:.2f}
INITIAL RECOMMENDATION: {recommendation}

Identify what drove LOW confidence. Look for:
- Evidence you may have missed in the resume profile
- Skills that are adjacent or transferable
- Whether initial scores were too harsh or too generous

Return updated JSON (same schema, same fields, no markdown):
{{"d1_skills": 0.XX, "d2_seniority": 0.XX, "d3_domain": 0.XX, "d4_constraints": 0.XX, "confidence": "HIGH|MEDIUM|LOW", "recommendation": "STRONG_MATCH|GOOD_MATCH|PARTIAL_MATCH|WEAK_MATCH|NO_MATCH", "strengths": ["..."], "gaps": ["..."], "rationale": "updated one paragraph"}}"""


def score_profiles(jd_profile: dict, resume_profile: dict) -> Optional[dict]:
    """Stage 2: Score one profile pair. Returns parsed dict or None."""
    prompt = _SCORING_PROMPT.format(
        few_shot=_FEW_SHOT_EXAMPLES,
        jd_profile_json=json.dumps(jd_profile, separators=(',', ':')),
        resume_profile_json=json.dumps(resume_profile, separators=(',', ':')),
    )
    raw = call_scoring_llm(prompt, max_tokens=700, system=_SCORING_SYSTEM)
    result = _parse_json(raw)
    if result and all(k in result for k in ("d1_skills", "d2_seniority", "d3_domain", "d4_constraints")):
        return result
    return None




def verify_score(jd_profile: dict, resume_profile: dict, initial: dict) -> Optional[dict]:
    """Agentic retry — bounded 1 call. Only triggered on LOW confidence."""
    prompt = _VERIFY_PROMPT.format(
        jd_profile_json=json.dumps(jd_profile, separators=(',', ':')),
        resume_profile_json=json.dumps(resume_profile, separators=(',', ':')),
        d1=initial.get("d1_skills", 0),
        d2=initial.get("d2_seniority", 0),
        d3=initial.get("d3_domain", 0),
        d4=initial.get("d4_constraints", 0),
        recommendation=initial.get("recommendation", "?"),
    )
    raw = call_scoring_llm(prompt, max_tokens=600, system=_SCORING_SYSTEM)
    result = _parse_json(raw)
    if result and all(k in result for k in ("d1_skills", "d2_seniority", "d3_domain", "d4_constraints")):
        return result
    return None


# ============================================================
# Deterministic scorer (fallback when no API key)
# ============================================================

BUILD_VERBS = {
    "built", "architected", "designed", "engineered", "developed",
    "implemented", "created", "deployed", "launched", "shipped",
    "automated", "migrated", "scaled", "optimized", "led",
    "managed", "orchestrated", "delivered", "integrated",
}

USE_VERBS = {
    "used", "utilized", "worked with", "contributed",
    "maintained", "supported", "configured", "applied", "leveraged",
}

ALIAS_MAP = {
    "rag": ["retrieval augmented generation", "rag pipeline", "llamaindex", "langchain", "faiss"],
    "llm": ["large language model", "gpt", "openai", "anthropic", "claude"],
    "python": ["django", "flask", "fastapi"],
    "typescript": ["javascript", "react", "node", "angular"],
    "docker": ["container", "containerized", "docker compose"],
    "kubernetes": ["k8s", "orchestration"],
    "postgresql": ["postgres", "sql"],
    "kafka": ["event-driven", "message queue", "rabbitmq"],
    "ci/cd": ["github actions", "jenkins", "continuous integration"],
    "microservices": ["micro-service", "service-oriented"],
    "aws": ["ec2", "s3", "lambda", "ecs", "dynamodb", "sqs"],
}

DOMAIN_KEYWORDS = {
    "fintech": ["fintech", "payment", "banking", "financial", "trading", "lending"],
    "enterprise_saas": ["enterprise", "saas", "b2b", "multi-tenant"],
    "ai_ml": ["ai", "machine learning", "llm", "gpt", "genai", "nlp", "rag"],
    "healthcare": ["healthcare", "medical", "clinical", "patient", "hipaa"],
    "platform_devops": ["platform", "devops", "kubernetes", "ci/cd", "infrastructure"],
    "ecommerce": ["ecommerce", "marketplace", "retail"],
}

ADJACENT_DOMAINS = {
    ("enterprise_saas", "fintech"), ("ai_ml", "enterprise_saas"),
    ("fintech", "platform_devops"), ("ai_ml", "fintech"),
}


def _expand_terms(skill_text: str):
    terms = set()
    skill_lower = skill_text.lower().strip()
    terms.add(skill_lower)
    for w in re.split(r'\W+', skill_lower):
        if len(w) > 2:
            terms.add(w)
    expanded = set()
    for t in terms:
        for key, aliases in ALIAS_MAP.items():
            if t in key or key in t or any(a in t or t in a for a in aliases):
                expanded.add(key)
                expanded.update(aliases)
    terms.update(expanded)
    return {t for t in terms if len(t) > 2}


def find_skill_evidence(skill_name: str, resume_text: str):
    terms = _expand_terms(skill_name)
    sentences = re.split(r'[.\n•]+', resume_text)
    matches = []
    for sent in sentences:
        sl = sent.lower().strip()
        if not sl or len(sl) < 10:
            continue
        if any(t in sl for t in terms):
            matches.append(sent.strip())
    if not matches:
        return "ABSENT", 0.0, ""
    for sent in matches:
        if any(v in sent.lower() for v in BUILD_VERBS):
            return "BUILT_WITH", 1.0, sent[:200]
    for sent in matches:
        if any(v in sent.lower() for v in USE_VERBS):
            return "USED", 0.7, sent[:200]
    return "LISTED", 0.3, matches[0][:200]


def assess_seniority(resume_text: str, jd_years: int = 0):
    rl = resume_text.lower()
    signals = {}
    lead = 0.0
    if re.search(r'led\s+(?:a\s+)?(?:team|development)|manag(?:ed|ing)\s+(?:a\s+)?\d+|mentor', rl):
        lead = 0.7
    m = re.search(r'(\d+)[\s-]*(engineer|person|member|people)\s*(team|group)', rl)
    if m:
        lead = max(lead, min(1.0, int(m.group(1)) / 6))
    signals["leadership"] = lead

    arch = 0.0
    for pat in [r'architect(?:ed|ing|ure)', r'design(?:ed|ing)\s+(?:a\s+)?(?:system|platform|pipeline)',
                r'technical\s+(?:architecture|decisions)', r'end[\s-]to[\s-]end']:
        if re.search(pat, rl):
            arch = max(arch, 0.9)
    signals["architecture"] = min(1.0, arch)

    scale = 0.0
    for pat, w in [(r'(\d[\d,]+)\+?\s*(?:active\s+)?users', 0.8),
                   (r'(\d[\d,]+)\+?\s*tps', 0.9), (r'\$[\d.]+[BMK]', 0.9)]:
        if re.search(pat, rl):
            scale = max(scale, w)
    signals["scale"] = min(1.0, scale)

    own = 0.0
    for pat, w in [(r'production\s+deployment', 0.8),
                   (r'from\s+(?:ideation|scratch)\s+(?:through|to)\s+production', 0.9)]:
        if re.search(pat, rl):
            own = max(own, w)
    signals["ownership"] = min(1.0, own)

    year_ranges = re.findall(
        r'(20\d{2})\s*[-–—]+\s*(20\d{2}|present|current|now)', resume_text.lower()
    )
    actual = 0
    if year_ranges:
        spans = [(int(s), 2026 if e in ('present', 'current', 'now') else int(e))
                 for s, e in year_ranges]
        actual = max(e for _, e in spans) - min(s for s, _ in spans)
    if jd_years > 0 and actual > 0:
        gap = jd_years - actual
        signals["years"] = 1.0 if gap <= 0 else 0.8 if gap <= 1 else 0.5 if gap <= 2 else 0.2
    else:
        signals["years"] = min(1.0, actual / 5) if actual > 0 else 0.3

    d2 = (0.25 * signals["leadership"] + 0.25 * signals["architecture"] +
          0.20 * signals["scale"] + 0.15 * signals["ownership"] + 0.15 * signals["years"])
    return round(d2, 4), signals


def assess_domain_fit(jd_text: str, resume_text: str):
    def _doms(text):
        tl = text.lower()
        r = []
        for d, kws in DOMAIN_KEYWORDS.items():
            h = sum(1 for kw in kws if kw in tl)
            if h > 0:
                r.append((d, round(min(1.0, h / max(2, len(kws) * 0.3)), 2)))
        r.sort(key=lambda x: x[1], reverse=True)
        return r
    jd_d = _doms(jd_text)
    res_d = _doms(resume_text)
    if not jd_d:
        return 0.5, "No JD domain found"
    if not res_d:
        return 0.3, "No resume domain found"
    jt = set(d for d, _ in jd_d[:2])
    rt = set(d for d, _ in res_d[:2])
    overlap = jt & rt
    if overlap:
        return round(min(1.0, 0.5 + 0.2 * len(overlap)), 4), f"Overlap: {', '.join(overlap)}"
    for j in jt:
        for r in rt:
            if (j, r) in ADJACENT_DOMAINS or (r, j) in ADJACENT_DOMAINS:
                return 0.55, f"Adjacent domains"
    return 0.25, f"Different domains: JD={jt} vs Resume={rt}"


def check_constraints(jd_text: str, resume_text: str):
    jl, rl = jd_text.lower(), resume_text.lower()
    checks = []

    ym = re.search(r'(\d+)\+?\s*years?\s*(?:of\s+)?(?:production\s+)?(?:software\s+)?(?:engineering\s+)?experience', jl)
    if ym:
        req = int(ym.group(1))
        yr = re.findall(r'(20\d{2})\s*[-–—]+\s*(20\d{2}|present|current|now)', rl)
        actual = 0
        if yr:
            spans = [(int(s), 2026 if e in ('present', 'current', 'now') else int(e)) for s, e in yr]
            actual = max(e for _, e in spans) - min(s for s, _ in spans)
        checks.append({"req": f"{req}+ yrs exp", "met": actual >= req, "partial": actual >= req - 1})

    LANGS = ["python", "go", "java", "typescript", "javascript", "rust", "scala"]
    jd_langs = [lang for lang in LANGS if lang in jl]
    if jd_langs:
        has_any = any(lang in rl for lang in jd_langs)
        has_all = all(lang in rl for lang in jd_langs)
        checks.append({"req": f"Lang ({'/'.join(jd_langs)})", "met": has_all, "partial": has_any})

    CLOUDS = [("aws", ["ec2", "s3", "lambda", "ecs"]), ("gcp", ["bigquery", "gke"]), ("azure", ["azure", "aks"])]
    for cloud, services in CLOUDS:
        if cloud in jl:
            in_resume = cloud in rl or any(svc in rl for svc in services)
            checks.append({"req": cloud.upper(), "met": in_resume, "partial": in_resume})
            break

    DBS = ["postgresql", "postgres", "mysql", "redis", "mongodb", "cassandra", "dynamodb"]
    jd_dbs = [db for db in DBS if db in jl]
    if jd_dbs:
        has_any = any(db in rl for db in jd_dbs)
        checks.append({"req": f"DB ({', '.join(jd_dbs[:3])})", "met": has_any, "partial": has_any})

    TECH_PATTERNS = [
        ("kafka", ["kafka", "kinesis", "event-driven", "message queue"]),
        ("microservices", ["microservice", "micro-service", "service mesh"]),
        ("docker", ["docker", "container", "kubernetes", "k8s"]),
    ]
    for kw, variants in TECH_PATTERNS:
        if kw in jl or any(v in jl for v in variants):
            found = kw in rl or any(v in rl for v in variants)
            checks.append({"req": kw, "met": found, "partial": found})

    if not checks:
        return 1.0, []
    score = sum(1.0 if c["met"] else (0.5 if c["partial"] else 0.0) for c in checks) / len(checks)
    return round(score, 4), checks


def score_deterministic(jd_text: str, resume_text: str) -> dict:
    """Fully deterministic scorer — no API calls."""
    reqs_text = jd_text
    # Extract bullet requirements
    reqs = []
    for line in jd_text.split('\n'):
        if line.strip().startswith(('*', '-', '•')):
            req = re.sub(r'^[*\-•]\s*', '', line.strip())
            if len(req) > 10:
                reqs.append(req)
    if not reqs:
        reqs = ["relevant experience"]
    reqs = reqs[:10]

    skills = []
    for req in reqs:
        level, score, evidence = find_skill_evidence(req, resume_text)
        skills.append({"skill": req[:80], "level": level, "score": score, "evidence": evidence[:150]})
    d1 = round(sum(s["score"] for s in skills) / max(len(skills), 1), 4)

    ym = re.search(r'(\d+)\+?\s*years?', jd_text.lower())
    d2, sen_sig = assess_seniority(resume_text, int(ym.group(1)) if ym else 0)
    d3, dom_reason = assess_domain_fit(jd_text, resume_text)
    d4, con_checks = check_constraints(jd_text, resume_text)

    built = sum(1 for s in skills if s["level"] == "BUILT_WITH")
    absent = sum(1 for s in skills if s["level"] == "ABSENT")
    total = max(len(skills), 1)
    conf = ("HIGH" if built / total >= 0.5 and absent / total <= 0.2
            else "LOW" if absent / total >= 0.5 else "MEDIUM")

    return {
        "d1_skills": {"score": d1, "skills_checked": skills},
        "d2_seniority": {"score": d2, "signals": [{"type": k, "score": v} for k, v in sen_sig.items()]},
        "d3_domain": {"score": d3, "reasoning": dom_reason},
        "d4_constraints": {"score": d4, "checks": con_checks},
        "confidence": conf,
        "strengths": [f"{s['skill'][:40]}: {s['level']}" for s in skills if s["level"] in ("BUILT_WITH", "USED")][:5],
        "gaps": [f"{s['skill'][:40]}: {s['level']}" for s in skills if s["level"] in ("ABSENT", "LISTED")][:4],
        "rationale": f"Skills: {d1:.0%}, Seniority: {d2:.0%}, Domain: {d3:.0%}, Constraints: {d4:.0%}",
    }


# ============================================================
# Unified interface — called by pipeline.py
# ============================================================

def compute_ce_weight(n_candidates: int) -> float:
    if n_candidates <= 1:
        return 0.0
    return min(MAX_CE_WEIGHT, MAX_CE_WEIGHT * (n_candidates - 1) / CE_RAMP_N)


def score_resume(
    jd_text: str,
    resume_text: str,
    ce_logit: float = 0.0,
    n_candidates: int = 1,
    adversarial_penalty: float = 0.0,
    verbose: bool = False,
    jd_profile: Optional[dict] = None,
    resume_profile: Optional[dict] = None,
) -> dict:
    """
    Score one resume against JD. Returns dict with all scores + metadata.

    Two-stage flow (when API available):
      1. Use pre-extracted jd_profile + resume_profile if provided by pipeline
      2. Otherwise extract them inline
      3. Score with few-shot gpt-4o
      4. Agentic retry if confidence == LOW (bounded 1 extra call)

    Deterministic fallback when no API key.
    """
    mode = "deterministic"
    result = None

    if LLM_PROVIDER in ("openai", "anthropic"):
        jdp = jd_profile or extract_jd_profile(jd_text)
        rsp = resume_profile or extract_resume_profile(resume_text)

        if jdp and rsp:
            result = score_profiles(jdp, rsp)
            mode = "llm_two_stage"

            if result and result.get("confidence") == "LOW":
                if verbose:
                    print(f"        [Agentic] LOW confidence — running verification pass")
                verified = verify_score(jdp, rsp, result)
                if verified:
                    result = verified
                    mode = "agentic_retry"

        if result is None:
            if verbose:
                print("        [Fallback] LLM scoring failed — using deterministic")
            fallback = score_deterministic(jd_text, resume_text)
            result = {
                "d1_skills": fallback["d1_skills"]["score"],
                "d2_seniority": fallback["d2_seniority"]["score"],
                "d3_domain": fallback["d3_domain"]["score"],
                "d4_constraints": fallback["d4_constraints"]["score"],
                "confidence": fallback["confidence"],
                "strengths": fallback["strengths"],
                "gaps": fallback["gaps"],
                "rationale": fallback["rationale"],
                "_raw_detail": fallback,
            }
            mode = "deterministic_fallback"
    else:
        fallback = score_deterministic(jd_text, resume_text)
        result = {
            "d1_skills": fallback["d1_skills"]["score"],
            "d2_seniority": fallback["d2_seniority"]["score"],
            "d3_domain": fallback["d3_domain"]["score"],
            "d4_constraints": fallback["d4_constraints"]["score"],
            "confidence": fallback["confidence"],
            "strengths": fallback["strengths"],
            "gaps": fallback["gaps"],
            "rationale": fallback["rationale"],
            "_raw_detail": fallback,
        }
        mode = "deterministic"

    # --- Pull scores ---
    d1 = float(result.get("d1_skills", 0))
    d2 = float(result.get("d2_seniority", 0))
    d3 = float(result.get("d3_domain", 0))
    d4 = float(result.get("d4_constraints", 0))

    # Clamp to [0,1] — LLM occasionally hallucinates values slightly outside
    d1, d2, d3, d4 = (max(0.0, min(1.0, v)) for v in (d1, d2, d3, d4))

    # --- CE blend ---
    dim = W_SKILLS * d1 + W_SENIORITY * d2 + W_DOMAIN * d3 + W_CONSTRAINTS * d4
    alpha = compute_ce_weight(n_candidates)
    ce_sig = 1.0 / (1.0 + math.exp(-ce_logit))
    raw = (1.0 - alpha) * dim + alpha * ce_sig
    final = round(max(0.0, min(1.0, raw * (1.0 - adversarial_penalty))), 4)

    if verbose:
        print(f"      D1={d1:.2f} D2={d2:.2f} D3={d3:.2f} D4={d4:.2f} | "
              f"dim={dim:.3f} CE={ce_sig:.3f}(w={alpha:.2f}) | "
              f"raw={raw:.3f} pen={adversarial_penalty:.2f} | "
              f"final={final:.4f} [{mode}]")

    conf = result.get("confidence", "MEDIUM")
    if n_candidates > CE_RAMP_N and ce_sig > 0:
        div = abs(dim - ce_sig)
        if div > 0.50:
            conf = "LOW"
        elif div > 0.30:
            conf = {"HIGH": "MEDIUM", "MEDIUM": "LOW", "LOW": "LOW"}.get(conf, "LOW")

    rec = result.get("recommendation") or (
        "STRONG_MATCH" if final >= 0.70 and conf in ("HIGH", "MEDIUM") else
        "GOOD_MATCH" if final >= 0.55 else
        "PARTIAL_MATCH" if final >= 0.35 else
        "WEAK_MATCH" if final >= 0.20 else "NO_MATCH"
    )

    # --- Build skill_detail for backward compat with demo.py ---
    raw_detail = result.get("_raw_detail", {})
    skill_detail = raw_detail.get("d1_skills", {}) if raw_detail else {}

    return {
        "d1_skills": d1, "d2_seniority": d2, "d3_domain": d3, "d4_constraints": d4,
        "dim_composite": round(dim, 4),
        "ce_sigmoid": round(ce_sig, 4), "ce_weight": round(alpha, 4),
        "raw_score": round(raw, 4), "adversarial_penalty": adversarial_penalty,
        "final_score": final, "confidence": conf,
        "recommendation": rec, "mode": mode,
        "strengths": result.get("strengths", []),
        "gaps": result.get("gaps", []),
        "rationale": result.get("rationale", ""),
        "skill_detail": skill_detail,
    }


# ============================================================
# Legacy stubs — kept for backward compat (ablation.py imports)
# ============================================================

def compute_base_score(ce_logit: float) -> float:
    """Sigmoid of cross-encoder logit → (0, 1)."""
    return 1.0 / (1.0 + math.exp(-ce_logit))


def compute_skill_penalty(skill_detail: dict):
    """Return (multiplier, evidence_list) based on missing critical skills."""
    CRITICAL_IMPORTANCE = 4
    SKILL_IMPORTANCE = {
        "python": 5, "java": 5, "javascript": 5, "typescript": 5,
        "aws": 5, "kubernetes": 5, "docker": 4, "kafka": 4,
        "postgresql": 4, "react": 4, "sql": 4,
    }
    PENALTY_PER_CRITICAL = 0.85

    missing = skill_detail.get("missing", [])
    evidence = []
    mult = 1.0

    for skill in missing:
        importance = SKILL_IMPORTANCE.get(skill.lower(), 3)
        if importance >= CRITICAL_IMPORTANCE:
            mult *= PENALTY_PER_CRITICAL
            evidence.append(SkillEvidence(requirement=skill, status="MISSING_CRITICAL",
                                           evidence_text="", evidence_location="none",
                                           confidence="HIGH", strength=0.0))
        else:
            evidence.append(SkillEvidence(requirement=skill, status="MISSING",
                                          evidence_text="", evidence_location="none",
                                          confidence="HIGH", strength=0.0))

    return round(mult, 4), evidence


def compute_final_score(ce_logit, skill_detail, adversarial_penalty=0.0):
    base = compute_base_score(ce_logit)
    penalty_mult, evidence = compute_skill_penalty(skill_detail)
    final = round(base * penalty_mult * (1.0 - adversarial_penalty), 4)
    return final, base, penalty_mult, evidence


def compute_confidence(evidence, llm_used=False):
    return "MEDIUM"


def classify_recommendation(score, confidence):
    if score >= 0.70 and confidence in ("HIGH", "MEDIUM"):
        return "STRONG_MATCH"
    if score >= 0.55:
        return "GOOD_MATCH"
    if score >= 0.35:
        return "PARTIAL_MATCH"
    if score >= 0.20:
        return "WEAK_MATCH"
    return "NO_MATCH"
