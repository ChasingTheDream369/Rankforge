"""
Hybrid Retrieval Engine — four-stage pipeline.

Stage 1a: BM25 sparse lexical retrieval (exact keyword matching)
Stage 1b: Dense bi-encoder semantic retrieval
           Priority: OpenAI text-embedding-3-small > sentence-transformers > TF-IDF
Stage 2:  Reciprocal Rank Fusion (RRF, k=60)
Stage 3:  Cross-encoder reranking on top-N candidates (always local)
"""

import re
import numpy as np
from typing import List, Tuple, Dict

from rank_bm25 import BM25Okapi
from src.config import (
    BM25_TOP_K, DENSE_TOP_K, RRF_K, RERANK_TOP_N,
    USE_OPENAI_EMBEDDINGS, OPENAI_API_KEY, OPENAI_EMBEDDING_MODEL,
)
def tokenize(text: str) -> List[str]:
    return re.findall(r'\b\w+\b', text.lower())
def openai_embed(texts: List[str]) -> np.ndarray:
    """Get embeddings from OpenAI API. Returns normalized numpy array."""
    from openai import OpenAI
    client = OpenAI(api_key=OPENAI_API_KEY)
    resp = client.embeddings.create(model=OPENAI_EMBEDDING_MODEL, input=texts)
    embeddings = np.array([d.embedding for d in resp.data])
    # L2 normalize for cosine similarity via dot product
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    norms[norms == 0] = 1
    return embeddings / norms
class RetrievalEngine:
    """Hybrid retrieval with BM25 + dense bi-encoder + RRF + cross-encoder."""

    def __init__(self):
        self.bm25 = None
        self.dense_embeddings = None
        self.doc_ids = []
        self.doc_texts = []
        self.last_ce_scores = {}
        self.last_ce_logits = {}  # raw logits before sigmoid

        # Embedding provider
        self.embed_provider = None  # "openai" | "sentence-transformers" | "tfidf"
        self.encoder = None
        self.cross_encoder = None

        if USE_OPENAI_EMBEDDINGS:
            self.embed_provider = "openai"
            print(f"  Bi-encoder: OpenAI {OPENAI_EMBEDDING_MODEL}")
        else:
            try:
                from sentence_transformers import SentenceTransformer
                from src.config import EMBEDDING_MODEL
                self.encoder = SentenceTransformer(EMBEDDING_MODEL)
                self.embed_provider = "sentence-transformers"
                print(f"  Bi-encoder: {EMBEDDING_MODEL} (local)")
            except ImportError:
                self.embed_provider = "tfidf"
                print("  Bi-encoder: TF-IDF fallback (no sentence-transformers)")

        # Cross-encoder is always local — no API equivalent
        try:
            from sentence_transformers import CrossEncoder
            from src.config import CROSS_ENCODER_MODEL
            self.cross_encoder = CrossEncoder(CROSS_ENCODER_MODEL)
            print(f"  Cross-encoder: {CROSS_ENCODER_MODEL} (local)")
        except ImportError:
            self.cross_encoder = None
            print("  Cross-encoder: unavailable (sentence-transformers not installed)")

    def embed_texts(self, texts: List[str]) -> np.ndarray:
        """Embed texts using the best available provider."""
        if self.embed_provider == "openai":
            return openai_embed(texts)
        elif self.embed_provider == "sentence-transformers":
            return self.encoder.encode(texts, show_progress_bar=False, normalize_embeddings=True)
        else:
            return None  # TF-IDF handled separately

    def embed_query(self, query: str) -> np.ndarray:
        """Embed a single query."""
        if self.embed_provider == "openai":
            return openai_embed([query])
        elif self.embed_provider == "sentence-transformers":
            return self.encoder.encode([query], show_progress_bar=False, normalize_embeddings=True)
        else:
            return None

    def index(self, documents: Dict[str, str],
              dense_documents: Dict[str, str] = None) -> None:
        """Build BM25 and dense indices from {doc_id: text}.

        documents       — clean sanitized text, used for BM25 (exact tokens only)
        dense_documents — ontology-expanded text for bi-encoder (optional).
                          Falls back to documents if not provided.
        """
        self.doc_ids = list(documents.keys())
        self.doc_texts = list(documents.values())

        # BM25 — raw clean text, no expansion (generic parent terms kill IDF)
        tokenized = [tokenize(t) for t in self.doc_texts]
        self.bm25 = BM25Okapi(tokenized)

        # Dense — expanded text if provided, else same clean text
        dense_texts = [dense_documents[did] for did in self.doc_ids] \
            if dense_documents else self.doc_texts

        if self.embed_provider in ("openai", "sentence-transformers"):
            self.dense_embeddings = self.embed_texts(dense_texts)
        else:
            from sklearn.feature_extraction.text import TfidfVectorizer
            self.tfidf = TfidfVectorizer(max_features=10000, ngram_range=(1, 2),
                                         sublinear_tf=True, stop_words='english')
            self.tfidf_matrix = self.tfidf.fit_transform(dense_texts)

    def search(self, query: str, dense_query: str = None) -> List[Tuple[str, float]]:
        """
        Full retrieval pipeline per the research architecture:
          1. BM25 → top BM25_TOP_K candidates (sparse lexical)
          2. Dense bi-encoder → top DENSE_TOP_K candidates (semantic)
          3. RRF fusion on the UNION of those two sets (~100 unique candidates)
          4. Cross-encoder reranking on top RERANK_TOP_N from RRF
        Returns [(doc_id, cross_encoder_score)] sorted descending.
        """
        n = len(self.doc_ids)
        if n == 0:
            return []

        # Stage 1a: BM25 — raw query, clean corpus (exact token matching)
        bm25_scores = self.bm25.get_scores(tokenize(query))
        bm25_top_indices = set(np.argsort(-bm25_scores)[:BM25_TOP_K])

        # Stage 1b: Dense — ontology-expanded query against expanded corpus
        dq = dense_query if dense_query is not None else query
        if self.embed_provider in ("openai", "sentence-transformers") and self.dense_embeddings is not None:
            q_emb = self.embed_query(dq)
            dense_scores = np.dot(self.dense_embeddings, q_emb.T).flatten()
        elif self.embed_provider == "tfidf":
            from sklearn.metrics.pairwise import cosine_similarity
            q_vec = self.tfidf.transform([dq])
            dense_scores = cosine_similarity(q_vec, self.tfidf_matrix).flatten()
        else:
            dense_scores = np.zeros(n)

        dense_top_indices = set(np.argsort(-dense_scores)[:DENSE_TOP_K])

        # Stage 2: RRF fusion ONLY on the union of both top-K sets
        # This is the key: we don't rank all N docs, only the ~100 candidates
        # that at least one retriever thought were relevant
        candidate_pool = bm25_top_indices | dense_top_indices
        candidate_list = sorted(candidate_pool)

        # Compute ranks within each retriever's full ordering
        bm25_rank_order = np.argsort(-bm25_scores)
        dense_rank_order = np.argsort(-dense_scores)
        bm25_rank_map = {int(idx): rank + 1 for rank, idx in enumerate(bm25_rank_order)}
        dense_rank_map = {int(idx): rank + 1 for rank, idx in enumerate(dense_rank_order)}

        rrf_results = []
        for idx in candidate_list:
            bm25_rank = bm25_rank_map.get(idx, n)
            dense_rank = dense_rank_map.get(idx, n)
            rrf_score = (1.0 / (RRF_K + bm25_rank)) + (1.0 / (RRF_K + dense_rank))
            rrf_results.append((idx, rrf_score))

        rrf_results.sort(key=lambda x: x[1], reverse=True)

        # Stage 3: Cross-encoder reranking on top-N from RRF
        top_n_indices = [idx for idx, _ in rrf_results[:RERANK_TOP_N]]

        if self.cross_encoder and top_n_indices:
            pairs = [(query, self.doc_texts[i]) for i in top_n_indices]
            ce_raw_scores = self.cross_encoder.predict(pairs, show_progress_bar=False)
            ce_normalized = [1.0 / (1.0 + np.exp(-s)) for s in ce_raw_scores]

            results = []
            for idx, ce_score in zip(top_n_indices, ce_normalized):
                results.append((self.doc_ids[idx], float(ce_score)))
            results.sort(key=lambda x: x[1], reverse=True)

            # Store both raw logits and sigmoid scores
            self.last_ce_logits = {self.doc_ids[idx]: float(raw)
                                     for idx, raw in zip(top_n_indices, ce_raw_scores)}
            self.last_ce_scores = {self.doc_ids[idx]: float(ce_score)
                                     for idx, ce_score in zip(top_n_indices, ce_normalized)}
        else:
            # No cross-encoder: scale RRF to logit range, apply sigmoid
            rrf_max = max(s for _, s in rrf_results) if rrf_results else 0.03
            scale = 4.0 / max(rrf_max, 0.001)
            self.last_ce_logits = {self.doc_ids[idx]: float(s * scale)
                                   for idx, s in rrf_results[:RERANK_TOP_N]}
            self.last_ce_scores = {did: float(1.0 / (1.0 + np.exp(-logit)))
                                   for did, logit in self.last_ce_logits.items()}
            results = sorted(self.last_ce_scores.items(), key=lambda x: x[1], reverse=True)

        # Append remaining candidates from RRF pool not in top-N
        top_set = set(idx for idx, _ in rrf_results[:RERANK_TOP_N])
        for idx, rrf_score in rrf_results[RERANK_TOP_N:]:
            results.append((self.doc_ids[idx], 0.0))  # below reranking cutoff

        # Append docs that didn't make either retriever's top-K
        seen = set(idx for idx, _ in rrf_results)
        for i in range(n):
            if i not in seen:
                results.append((self.doc_ids[i], 0.0))

        return results

    def get_cross_encoder_score(self, doc_id: str) -> float:
        """Get the sigmoid-normalized cross-encoder score."""
        return self.last_ce_scores.get(doc_id, 0.0)

    def get_cross_encoder_logit(self, doc_id: str) -> float:
        """Get the raw cross-encoder logit (before sigmoid). Used by scorer."""
        return self.last_ce_logits.get(doc_id, 0.0)

    def get_stage_scores(self, query: str, doc_id: str) -> dict:
        """Get per-stage scores for a specific document (for explainability)."""
        idx = self.doc_ids.index(doc_id) if doc_id in self.doc_ids else -1
        if idx < 0:
            return {}

        bm25_scores = self.bm25.get_scores(tokenize(query))
        if self.embed_provider in ("openai", "sentence-transformers") and self.dense_embeddings is not None:
            q_emb = self.embed_query(query)
            dense_scores = np.dot(self.dense_embeddings, q_emb.T).flatten()
        else:
            dense_scores = np.zeros(len(self.doc_ids))

        return {
            "bm25": round(float(bm25_scores[idx]), 4),
            "dense": round(float(dense_scores[idx]), 4),
            "embed_provider": self.embed_provider,
        }
